/*Question 2:
Create a Class User with properties as name, age & email.
He can login and logout
Create another class Moderator which has all the features of User, plus additional functionality to Add
coins and remove coins.
Create one more class Admin which has all the features of Moderator plus additional features like add a
Course and delete a particular course for a user.*/

class User {
    constructor(name, age,email) {
      this.name = name;
      this.age = age;
      this.email = email;
      this.luCoins = 0;
      this.courses = [];
    }

    static greet(){
        console.log("Hello There");
    }

    login(){
        console.log(`${this.name} has logged in`);
        return this;
    }
    logout(){
        console.log(`${this.name} has logged out`);
        return this;
    }
    addCoins(){
        this.luCoins++;
        console.log(`${this.name} has ${this.luCoins} coins`);
        return this;
    }
    getDetails(){
        console.log(`Name is ${this.name}, email is ${this.email}`);
        return this;
    }

}

class Moderator extends User{
    constructor(name,age,email,role){
        super(name,age,email);
        this.role = role;
    }

    deleteUser(user){
        users = users.filter(u =>{
            return u.email != user.email; 
        })
    }

}

class Admin extends Moderator{
   addCourse(user,course){
       user.courses.push(course);
       console.log(user);
   }
}
let user1 = new User('asim',20,'asim@gmail.com')
let user2 = new User('amol',222,'A@gmai.com')
let mod = new Moderator('Barkha',22,'b@gmail.com','Moderator');
let admin = new Admin('Reema',25,'r@gmail.com');
let users = [user1,user2,mod,admin];

users.forEach(element => {
    console.log(element);
});

User.greet();
admin.addCourse(user1,'Javascript');
admin.addCourse(user1,'Python');



 user1.login()
 user1.addCoins();
 user1.addCoins();
user1.addCoins();
 user1.logout()

 user1.login().addCoins().addCoins().getDetails().logout();

 mod.deleteUser(user1);
 console.log(users);
 
