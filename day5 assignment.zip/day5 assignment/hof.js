/*Question 1:
Write a program which does the following things:
1. Takes a positive number from the user.
2. Makes an array of numbers till the number given by user
3. Use higher order function to filter the odd numbers
4. Generate and array of the cubes of the filtered numbers*/


var arr=[i];
var size=9;
for(var i=0;i<size;i++){
    arr[i]=prompt("Enter the numbers");
}
console.log(arr);
let odd=arr.filter(el=>el%2===1)
console.log(odd); 
let oddCube=arr.filter(el=>el%2===1).map(el=>el**3);
console.log(oddCube);
